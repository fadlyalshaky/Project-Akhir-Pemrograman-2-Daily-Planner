Troggan's JCalendar and other stuff can be found here:
http://www.wannawork.de